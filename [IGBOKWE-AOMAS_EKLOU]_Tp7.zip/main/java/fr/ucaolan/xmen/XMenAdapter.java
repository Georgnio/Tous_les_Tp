package fr.ucaolan.xmen;


import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import fr.ucaolan.xmen.databinding.XMenBinding;
import io.realm.RealmRecyclerViewAdapter;
import io.realm.RealmResults;

public class XMenAdapter extends RealmRecyclerViewAdapter<XMen, XMenViewHolder>
{
    private XMenAdapter.OnItemClickListener onItemClickListener;

    public XMenAdapter(RealmResults<XMen> liste) {
        super(liste, true);
    }

    @NonNull
    @Override
    public XMenViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        XMenBinding ui = XMenBinding.inflate(
                LayoutInflater.from(parent.getContext()),
                parent,
                false
        );
        return new XMenViewHolder(ui);
    }

    @Override
    public void onBindViewHolder(@NonNull XMenViewHolder holder, int position) {
        holder.setXMen(getItem(position));
        holder.setOnItemClickListener(onItemClickListener);

    }
    public void setOnItemClickListener(OnItemClickListener onItemClickListener)
    {
        this.onItemClickListener = onItemClickListener;
    }

    public interface OnItemClickListener
    {
        public void onItemClick(int position);
    }
}

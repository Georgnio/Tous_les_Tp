package fr.ucaolan.xmen;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.EditText;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import fr.ucaolan.xmen.databinding.ActivityMainBinding;
import io.realm.Realm;
import io.realm.RealmResults;

public class MainActivity extends AppCompatActivity
{
    private ActivityMainBinding ui;
    private Realm realm;
    private XMenAdapter adapter;

    @Override

    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        ui = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(ui.getRoot());

        realm = Realm.getDefaultInstance();

        RealmResults<XMen> liste = realm.where(XMen.class).findAll();

        adapter = new XMenAdapter(liste);
        adapter.setOnItemClickListener(this::onItemClick);

        ui.recycler.setAdapter(adapter);

        ui.recycler.hasFixedSize();

        RecyclerView.LayoutManager lm = new LinearLayoutManager(this);
        ui.recycler.setLayoutManager(lm);

        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(
                this, DividerItemDecoration.VERTICAL
        );
        ui.recycler.addItemDecoration(dividerItemDecoration);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        XMenApplication application = (XMenApplication) getApplication();
        int idItem = item.getItemId();
        if (idItem == R.id.reinit)
        {
            application.initListe();
            adapter.notifyDataSetChanged();
            return true;
        }
        if (idItem == R.id.create)
        {
            onEdit(-1);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        int position = item.getOrder();

        switch (item.getItemId())
        {
            case XMenViewHolder.MENU_EDIT:
            {
                onEdit(position);
                return true;
            }

            case XMenViewHolder.MENU_DELETE: {
                onDelete(position);
                return true;
            }
        }
        return super.onContextItemSelected(item);
    }

    @Override
    protected void onDestroy() {
        realm.close();
        super.onDestroy();
    }

    /**
     * lancer l'edition sur un XMen par position indique si position == -1 alors creation
     * @param position index de la liste mettre -1 si on veut creer un xmen
     */
    private void onEdit(int position)
    {
        Intent editIntent = new Intent(MainActivity.this, EditActivity.class);
        if (position >= 0) {
            XMen xMen = adapter.getItem(position);

            editIntent.putExtra(EditActivity.EXTRA_ID, xMen.getId());
        }
        startActivity(editIntent);
    }

    private void onItemClick(int position)
    {
        XMen xmen = adapter.getItem(position);
        if (xmen == null) return;

        realm.beginTransaction();
        xmen.setIdImage(R.drawable.undef);
        realm.commitTransaction();
    }

    private void onReallyDelete(int position)
    {
        XMen xmen = adapter.getItem(position);
        if (xmen != null){
            realm.beginTransaction();
            xmen.deleteFromRealm();
            realm.commitTransaction();
        }
    }

    private void onDelete(int position)
    {
        XMen xmen = adapter.getItem(position);
        if (xmen == null) return;
        new AlertDialog.Builder(this)
                .setTitle(xmen.getNom())
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setMessage("Vous confirmez la suppression")
                .setPositiveButton(android.R.string.ok, (dialog, which) -> onReallyDelete(position))
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }
}